package com.priceminister.account;

import com.priceminister.account.implementation.CustomerAccount;
import com.priceminister.account.implementation.CustomerAccountRule;

/*
 * @author Youness CHAFIA
 * @version 1.0
 * @see my Github on : https://github.com/ychafia
 * */
public class Application {

	/**
	 * @param args
	 * @throws IllegalBalanceException 
	 */
	public static void main(String[] args) throws IllegalBalanceException {
		System.out.println("*******************************************************************************************");
		System.out.println("******** Retrait normal ne d�clanchant pas l'exception IllegalBalanceException ************");
		System.out.println("*******************************************************************************************");
		Account customerAccount = new CustomerAccount();
		customerAccount.add(2000.0);
		System.out.println("Le soldu du compte est de : " + customerAccount.getBalance() + " EUR");
		
		AccountRule rule = new CustomerAccountRule();
		customerAccount.withdrawAndReportBalance(1500.0, rule);
		System.out.println("Le solde apr�s un retrait de 1500.0 EUR : " + customerAccount.getBalance() + " EUR");
		
		
		System.out.println("*******************************************************************************************");
		System.out.println("************** Retrait d�clanchant l'exception IllegalBalanceException *******************");
		System.out.println("*******************************************************************************************");
		
		customerAccount.withdrawAndReportBalance(2000.0, rule);
		System.out.println("Le solde apr�s un retrait de 2000.0 EUR : " + customerAccount.getBalance());
		
	}

}
